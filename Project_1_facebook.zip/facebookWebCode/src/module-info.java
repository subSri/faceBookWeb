/**
 * 
 */
/**
 * @author SUBHAM
 *
 */
module facebookWeb {
	requires java.desktop;
	requires jdk.jdi;
	requires java.sql;
}